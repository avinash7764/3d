// Generates demo STL models into public/demo: a spur gear and a bicycle frame.
import { mkdirSync, writeFileSync } from "fs";

mkdirSync("public/demo", { recursive: true });

const tris = { gear: [], frame: [] };

function tri(bucket, a, b, c) {
  bucket.push([a, b, c]);
}

function quad(bucket, a, b, c, d) {
  tri(bucket, a, b, c);
  tri(bucket, a, c, d);
}

// ---------------- Spur gear ----------------
{
  const teeth = 20;
  const rOuter = 10;
  const rRoot = 8.4;
  const rHole = 2.2;
  const depth = 2.4;
  const stepsPerTooth = 8;
  const N = teeth * stepsPerTooth;

  const profile = [];
  for (let i = 0; i < N; i++) {
    const t = (i % stepsPerTooth) / stepsPerTooth; // position within tooth
    // trapezoidal tooth: root -> flank -> tip -> flank -> root
    let r;
    if (t < 0.2) r = rRoot;
    else if (t < 0.35) r = rRoot + ((t - 0.2) / 0.15) * (rOuter - rRoot);
    else if (t < 0.65) r = rOuter;
    else if (t < 0.8) r = rOuter - ((t - 0.65) / 0.15) * (rOuter - rRoot);
    else r = rRoot;
    const a = (i / N) * Math.PI * 2;
    profile.push([r * Math.cos(a), r * Math.sin(a)]);
  }
  const hole = [];
  for (let i = 0; i < N; i++) {
    const a = (i / N) * Math.PI * 2;
    hole.push([rHole * Math.cos(a), rHole * Math.sin(a)]);
  }

  const zTop = depth / 2;
  const zBot = -depth / 2;
  for (let i = 0; i < N; i++) {
    const j = (i + 1) % N;
    const [ox1, oy1] = profile[i];
    const [ox2, oy2] = profile[j];
    const [hx1, hy1] = hole[i];
    const [hx2, hy2] = hole[j];
    // top cap
    quad(tris.gear, [ox1, oy1, zTop], [ox2, oy2, zTop], [hx2, hy2, zTop], [hx1, hy1, zTop]);
    // bottom cap
    quad(tris.gear, [hx1, hy1, zBot], [hx2, hy2, zBot], [ox2, oy2, zBot], [ox1, oy1, zBot]);
    // outer wall
    quad(tris.gear, [ox1, oy1, zBot], [ox2, oy2, zBot], [ox2, oy2, zTop], [ox1, oy1, zTop]);
    // hole wall
    quad(tris.gear, [hx1, hy1, zTop], [hx2, hy2, zTop], [hx2, hy2, zBot], [hx1, hy1, zBot]);
  }
}

// ---------------- Bicycle frame (tubes) ----------------
{
  const SEG = 16;
  function cylinder(bucket, p0, p1, radius) {
    const [x0, y0, z0] = p0;
    const [x1, y1, z1] = p1;
    const dx = x1 - x0, dy = y1 - y0, dz = z1 - z0;
    const len = Math.hypot(dx, dy, dz);
    const ax = [dx / len, dy / len, dz / len];
    // find perpendicular
    let up = Math.abs(ax[1]) < 0.9 ? [0, 1, 0] : [1, 0, 0];
    const u = norm(cross(ax, up));
    const v = norm(cross(ax, u));
    const ring0 = [], ring1 = [];
    for (let i = 0; i < SEG; i++) {
      const a = (i / SEG) * Math.PI * 2;
      const off = [
        radius * (u[0] * Math.cos(a) + v[0] * Math.sin(a)),
        radius * (u[1] * Math.cos(a) + v[1] * Math.sin(a)),
        radius * (u[2] * Math.cos(a) + v[2] * Math.sin(a)),
      ];
      ring0.push([x0 + off[0], y0 + off[1], z0 + off[2]]);
      ring1.push([x1 + off[0], y1 + off[1], z1 + off[2]]);
    }
    for (let i = 0; i < SEG; i++) {
      const j = (i + 1) % SEG;
      quad(bucket, ring0[i], ring0[j], ring1[j], ring1[i]);
      // end caps (fans)
      tri(bucket, [x0, y0, z0], ring0[j], ring0[i]);
      tri(bucket, [x1, y1, z1], ring1[i], ring1[j]);
    }
  }
  function cross(a, b) {
    return [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
  }
  function norm(a) {
    const l = Math.hypot(...a) || 1;
    return [a[0] / l, a[1] / l, a[2] / l];
  }

  // frame geometry (side view, x right, y up)
  const rearAxle = [0, 0, 0];
  const bb = [42, -2, 0]; // bottom bracket
  const seatTop = [38, 42, 0];
  const headTop = [78, 40, 0];
  const headBot = [84, 22, 0];
  const frontAxle = [92, 0, 0];
  const R = 2.2;

  cylinder(tris.frame, seatTop, headTop, R); // top tube
  cylinder(tris.frame, headBot, bb, R); // down tube
  cylinder(tris.frame, seatTop, bb, R); // seat tube
  cylinder(tris.frame, headTop, headBot, R + 0.6); // head tube
  cylinder(tris.frame, rearAxle, bb, 1.5); // chainstay
  cylinder(tris.frame, rearAxle, seatTop, 1.5); // seatstay
  cylinder(tris.frame, headBot, frontAxle, 1.6); // fork
  cylinder(tris.frame, [34, 42, 0], [38, 42, 0], 1.4); // seat post nub
  // wheels as thin torus-ish rings approximated by short cylinders
  function wheel(cx, cy, r) {
    const S = 28;
    for (let i = 0; i < S; i++) {
      const a0 = (i / S) * Math.PI * 2;
      const a1 = ((i + 1) / S) * Math.PI * 2;
      cylinder(
        tris.frame,
        [cx + r * Math.cos(a0), cy + r * Math.sin(a0), 0],
        [cx + r * Math.cos(a1), cy + r * Math.sin(a1), 0],
        1.1
      );
    }
  }
  wheel(0, 0, 22);
  wheel(92, 0, 22);
}

// ---------------- write binary STL ----------------
function writeStl(path, triangles) {
  const buf = Buffer.alloc(84 + triangles.length * 50);
  buf.write("CADFolio demo model", 0, "ascii");
  buf.writeUInt32LE(triangles.length, 80);
  let o = 84;
  for (const [a, b, c] of triangles) {
    const u = [b[0] - a[0], b[1] - a[1], b[2] - a[2]];
    const v = [c[0] - a[0], c[1] - a[1], c[2] - a[2]];
    let n = [u[1] * v[2] - u[2] * v[1], u[2] * v[0] - u[0] * v[2], u[0] * v[1] - u[1] * v[0]];
    const l = Math.hypot(...n) || 1;
    n = n.map((x) => x / l);
    buf.writeFloatLE(n[0], o); buf.writeFloatLE(n[1], o + 4); buf.writeFloatLE(n[2], o + 8);
    o += 12;
    for (const p of [a, b, c]) {
      buf.writeFloatLE(p[0], o); buf.writeFloatLE(p[1], o + 4); buf.writeFloatLE(p[2], o + 8);
      o += 12;
    }
    buf.writeUInt16LE(0, o);
    o += 2;
  }
  writeFileSync(path, buf);
  console.log(`${path}: ${triangles.length} triangles`);
}

writeStl("public/demo/gear.stl", tris.gear);
writeStl("public/demo/bicycle-frame.stl", tris.frame);
