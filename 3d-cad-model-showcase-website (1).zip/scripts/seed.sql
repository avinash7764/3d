-- Seed demo data (idempotent: only inserts when the projects table is empty)
DO $$
BEGIN
  IF (SELECT COUNT(*) FROM projects) = 0 THEN

    INSERT INTO projects (title, description, category, tags, cover_image_url, sort_order)
    VALUES (
      'Lightweight Bicycle Frame',
      'Structural design using weldments and surface modeling. Integrated static FEA analysis which drove a 15% reduction in total weight while maintaining structural safety factors.',
      'Design',
      'CATIA V5, Weldments, FEA Analysis',
      '/demo/bike-blueprint-1.png',
      1
    );

    INSERT INTO media_items (project_id, kind, format, url, label, sort_order) VALUES
      (currval('projects_id_seq'), 'model', 'stl', '/demo/bicycle-frame.stl', 'Frame Digital Twin (STL)', 1),
      (currval('projects_id_seq'), 'image', '', '/demo/bike-blueprint-1.png', 'CAD / Simulation Preview', 1),
      (currval('projects_id_seq'), 'image', '', '/demo/bike-fea.png', 'Static FEA Stress Plot', 2),
      (currval('projects_id_seq'), 'image', '', '/demo/bike-exploded.png', 'Exploded Assembly View', 3),
      (currval('projects_id_seq'), 'video', '', 'https://www.youtube.com/watch?v=aqz-KE-bpKQ', 'Product Kinematics & Disassembly Video', 1);

    INSERT INTO projects (title, description, category, tags, cover_image_url, sort_order)
    VALUES (
      'Precision Spur Gear Drive',
      '20-tooth involute spur gear machined from brass. Parametric CAD model with tolerance stack-up analysis and kinematic mesh simulation for a 3:1 reduction drive stage.',
      'Mechanism',
      'SolidWorks, GD&T, Kinematics',
      '/demo/gear-cover.png',
      2
    );

    INSERT INTO media_items (project_id, kind, format, url, label, sort_order) VALUES
      (currval('projects_id_seq'), 'model', 'stl', '/demo/gear.stl', 'Spur Gear (STL)', 1),
      (currval('projects_id_seq'), 'image', '', '/demo/gear-cover.png', 'Gear Blueprint', 1),
      (currval('projects_id_seq'), 'image', '', '/demo/gear-render.png', 'Product Render', 2),
      (currval('projects_id_seq'), 'video', '', 'https://www.youtube.com/watch?v=jGeAamMSc5o', 'Gear Meshing Animation', 1);

  END IF;
END $$;
