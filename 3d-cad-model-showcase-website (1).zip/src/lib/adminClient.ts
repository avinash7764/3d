"use client";

const PASS_KEY = "cadfolio_admin_pass";

/**
 * The password is kept in memory FIRST (module scope), with web storage as a
 * best-effort convenience. Storage is unreliable inside cross-site iframes, so
 * it must never be the only copy — that was the cause of the bogus
 * "session expired" errors.
 */
let memPassword = "";

function safeGet(key: string): string {
  if (typeof window === "undefined") return "";
  try {
    return window.sessionStorage.getItem(key) || window.localStorage.getItem(key) || "";
  } catch {
    return "";
  }
}

function safeSet(key: string, value: string): void {
  if (typeof window === "undefined") return;
  try {
    window.sessionStorage.setItem(key, value);
  } catch {
    /* ignore */
  }
  try {
    window.localStorage.setItem(key, value);
  } catch {
    /* ignore */
  }
}

function safeRemove(key: string): void {
  if (typeof window === "undefined") return;
  try {
    window.sessionStorage.removeItem(key);
  } catch {
    /* ignore */
  }
  try {
    window.localStorage.removeItem(key);
  } catch {
    /* ignore */
  }
}

export function getAdminPassword(): string {
  return memPassword || safeGet(PASS_KEY);
}

export function setAdminPassword(password: string): void {
  memPassword = password;
  safeSet(PASS_KEY, password);
}

export function clearAdminPassword(): void {
  memPassword = "";
  safeRemove(PASS_KEY);
}

export function hasAdminPassword(): boolean {
  return Boolean(getAdminPassword());
}

/** Verifies a password against the server. Stores it on success. */
export async function login(password: string): Promise<{ ok: boolean; error?: string }> {
  try {
    const res = await fetch("/api/admin/session", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ password }),
      cache: "no-store",
    });
    if (res.status === 401) return { ok: false, error: "Incorrect password." };
    if (!res.ok) return { ok: false, error: `Login failed (${res.status}).` };
    setAdminPassword(password);
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "Network error" };
  }
}

/** Confirms the cached password is still valid (used on page load). */
export async function verifyStoredPassword(): Promise<boolean> {
  const pw = getAdminPassword();
  if (!pw) return false;
  try {
    const res = await fetch(`/api/admin/session?pw=${encodeURIComponent(pw)}`, {
      headers: { "x-admin-password": pw },
      cache: "no-store",
    });
    if (!res.ok) return false;
    const data = (await res.json()) as { authenticated?: boolean };
    if (data.authenticated) {
      setAdminPassword(pw); // refresh the in-memory copy
      return true;
    }
    return false;
  } catch {
    return false;
  }
}

export type ApiResult<T> =
  | { ok: true; data: T }
  | { ok: false; error: string; unauthorized: boolean };

/**
 * Fetch wrapper for admin operations. The password travels with every request,
 * so there is no session to expire and no re-authentication dance.
 */
export async function adminFetch<T = unknown>(
  url: string,
  init: RequestInit = {}
): Promise<ApiResult<T>> {
  const headers = new Headers(init.headers);
  if (init.body && !headers.has("Content-Type")) {
    headers.set("Content-Type", "application/json");
  }
  const pw = getAdminPassword();
  if (pw) {
    headers.set("x-admin-password", pw);
    headers.set("authorization", `Bearer ${pw}`);
  }

  // Query-string fallback: guarantees the credential arrives even if an
  // intermediate proxy strips custom request headers.
  let target = url;
  if (pw) {
    target += (url.includes("?") ? "&" : "?") + "pw=" + encodeURIComponent(pw);
  }

  let res: Response;
  try {
    res = await fetch(target, { ...init, headers, cache: "no-store" });
  } catch (e) {
    return {
      ok: false,
      error: e instanceof Error ? e.message : "Network error",
      unauthorized: false,
    };
  }

  let payload: unknown = null;
  const text = await res.text();
  if (text) {
    try {
      payload = JSON.parse(text);
    } catch {
      payload = null;
    }
  }

  if (!res.ok) {
    const serverMsg =
      payload && typeof payload === "object" && "error" in payload
        ? String((payload as { error: unknown }).error)
        : "";
    if (res.status === 401) {
      return {
        ok: false,
        error: "The admin password was rejected. Please sign in again.",
        unauthorized: true,
      };
    }
    return { ok: false, error: serverMsg || `Request failed (${res.status})`, unauthorized: false };
  }

  return { ok: true, data: payload as T };
}
