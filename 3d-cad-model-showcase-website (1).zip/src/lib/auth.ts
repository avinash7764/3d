import { headers } from "next/headers";
import type { NextRequest } from "next/server";

export const ADMIN_HEADER = "x-admin-password";
export const ADMIN_QUERY = "pw";

export function adminPassword(): string {
  return process.env.ADMIN_PASSWORD || "admin123";
}

function matches(value: string | null | undefined): boolean {
  return typeof value === "string" && value.length > 0 && value === adminPassword();
}

/**
 * Stateless auth — the password travels with every admin request, so there is
 * no session, cookie or token that can expire or be dropped by a browser.
 *
 * Three transports are accepted so a stripped header or blocked cookie can
 * never lock the admin out:
 *   1. `x-admin-password` header
 *   2. `Authorization: Bearer <password>`
 *   3. `?pw=<password>` query string
 */
export async function isAdmin(req?: NextRequest): Promise<boolean> {
  if (req) {
    if (matches(req.headers.get(ADMIN_HEADER))) return true;
    const auth = req.headers.get("authorization") || "";
    if (auth.toLowerCase().startsWith("bearer ") && matches(auth.slice(7).trim())) return true;
    if (matches(req.nextUrl.searchParams.get(ADMIN_QUERY))) return true;
  }

  try {
    const h = await headers();
    if (matches(h.get(ADMIN_HEADER))) return true;
    const auth = h.get("authorization") || "";
    if (auth.toLowerCase().startsWith("bearer ") && matches(auth.slice(7).trim())) return true;
  } catch {
    /* ignore */
  }

  return false;
}
