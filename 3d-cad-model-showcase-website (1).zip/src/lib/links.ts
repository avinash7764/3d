// Utilities for turning Google Drive / YouTube share links into usable media sources.

export const MODEL_FORMATS = ["stl", "obj", "igs", "iges", "fbx", "glb", "gltf"] as const;
export type ModelFormat = (typeof MODEL_FORMATS)[number];

export function extractDriveId(url: string): string | null {
  if (!/drive\.google\.com|docs\.google\.com|drive\.usercontent\.google\.com/.test(url)) {
    return null;
  }
  const patterns = [
    /\/file\/d\/([a-zA-Z0-9_-]{10,})/,
    /[?&]id=([a-zA-Z0-9_-]{10,})/,
    /\/d\/([a-zA-Z0-9_-]{10,})/,
    /\/uc\/([a-zA-Z0-9_-]{10,})/,
  ];
  for (const p of patterns) {
    const m = url.match(p);
    if (m) return m[1];
  }
  return null;
}

export function driveDirectUrl(id: string): string {
  return `https://drive.google.com/uc?export=download&id=${id}`;
}

export function extractYouTubeId(url: string): string | null {
  if (!/youtube\.com|youtu\.be/.test(url)) return null;
  const patterns = [
    /youtu\.be\/([a-zA-Z0-9_-]{6,})/,
    /[?&]v=([a-zA-Z0-9_-]{6,})/,
    /\/embed\/([a-zA-Z0-9_-]{6,})/,
    /\/shorts\/([a-zA-Z0-9_-]{6,})/,
    /\/live\/([a-zA-Z0-9_-]{6,})/,
  ];
  for (const p of patterns) {
    const m = url.match(p);
    if (m) return m[1];
  }
  return null;
}

export function isYouTubeUrl(url: string): boolean {
  return extractYouTubeId(url) !== null;
}

export function isDriveUrl(url: string): boolean {
  return extractDriveId(url) !== null;
}

/**
 * Returns a browser-loadable source for binary assets (3D models, images).
 * Google Drive / remote URLs are routed through our server-side proxy so the
 * browser never hits CORS or hot-linking restrictions.
 */
export function resolveAssetSrc(url: string): string {
  const trimmed = url.trim();
  if (!trimmed) return trimmed;
  const driveId = extractDriveId(trimmed);
  if (driveId) {
    return `/api/proxy?src=${encodeURIComponent(driveDirectUrl(driveId))}`;
  }
  if (/^https?:\/\//i.test(trimmed)) {
    return `/api/proxy?src=${encodeURIComponent(trimmed)}`;
  }
  return trimmed; // local /public asset or relative path
}

/** Returns an iframe embed URL for videos, or null when a <video> tag should be used. */
export function videoEmbedUrl(url: string): string | null {
  const yt = extractYouTubeId(url);
  if (yt) return `https://www.youtube.com/embed/${yt}?rel=0`;
  const driveId = extractDriveId(url);
  if (driveId) return `https://drive.google.com/file/d/${driveId}/preview`;
  return null;
}

export function detectModelFormat(url: string, explicit?: string, label?: string): ModelFormat | null {
  const exp = (explicit || "").toLowerCase().trim();
  if (exp === "iges") return "igs";
  if ((MODEL_FORMATS as readonly string[]).includes(exp)) return exp as ModelFormat;
  const haystacks = [url, label || ""];
  for (const h of haystacks) {
    const m = h.toLowerCase().match(/\.(stl|obj|igs|iges|fbx|glb|gltf)(\?|#|$)/);
    if (m) return (m[1] === "iges" ? "igs" : m[1]) as ModelFormat;
  }
  return null;
}

export function shortDriveLabel(url: string): string {
  const id = extractDriveId(url);
  if (id) return `Drive (${id.slice(0, 8)}…)`;
  const yt = extractYouTubeId(url);
  if (yt) return `YouTube (${yt})`;
  try {
    const u = new URL(url, "http://local");
    const last = u.pathname.split("/").pop();
    return last || url;
  } catch {
    return url;
  }
}
