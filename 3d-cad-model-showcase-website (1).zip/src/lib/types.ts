export type ViewerTab = "model" | "images" | "video";

export type MediaItemDto = {
  id: number;
  projectId: number;
  kind: string; // "model" | "image" | "video"
  format: string;
  url: string;
  label: string;
  sortOrder: number;
};

export type ProjectDto = {
  id: number;
  title: string;
  description: string;
  category: string;
  tags: string;
  coverImageUrl: string;
  sortOrder: number;
  media: MediaItemDto[];
};
