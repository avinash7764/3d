import { asc } from "drizzle-orm";
import Link from "next/link";
import { db } from "@/db";
import { mediaItems, projects } from "@/db/schema";
import type { ProjectDto } from "@/lib/types";
import ShowcaseClient from "@/components/ShowcaseClient";

export const dynamic = "force-dynamic";

async function loadProjects(): Promise<ProjectDto[]> {
  try {
    const projectRows = await db
      .select()
      .from(projects)
      .orderBy(asc(projects.sortOrder), asc(projects.id));
    const mediaRows = await db
      .select()
      .from(mediaItems)
      .orderBy(asc(mediaItems.sortOrder), asc(mediaItems.id));
    return projectRows.map((p) => ({
      id: p.id,
      title: p.title,
      description: p.description,
      category: p.category,
      tags: p.tags,
      coverImageUrl: p.coverImageUrl,
      sortOrder: p.sortOrder,
      media: mediaRows
        .filter((m) => m.projectId === p.id)
        .map((m) => ({
          id: m.id,
          projectId: m.projectId,
          kind: m.kind,
          format: m.format,
          url: m.url,
          label: m.label,
          sortOrder: m.sortOrder,
        })),
    }));
  } catch {
    return [];
  }
}

export default async function HomePage() {
  const data = await loadProjects();

  return (
    <main className="min-h-screen bg-gradient-to-b from-indigo-50 via-slate-100 to-violet-100">
      {/* Top nav */}
      <nav className="border-b border-slate-200/60 bg-white/70 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
          <div className="flex items-center gap-2.5">
            <svg className="h-7 w-7 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M12 3l9 5-9 5-9-5 9-5zM3 13l9 5 9-5M3 17l9 5 9-5" />
            </svg>
            <span className="text-lg font-extrabold tracking-tight text-slate-900">
              CAD<span className="text-indigo-600">Folio</span>
            </span>
          </div>
          <Link
            href="/admin"
            className="rounded-lg border border-slate-300 bg-white px-4 py-2 text-sm font-semibold text-slate-700 shadow-sm transition hover:bg-slate-50"
          >
            Admin Panel
          </Link>
        </div>
      </nav>

      {/* Hero */}
      <header className="mx-auto max-w-6xl px-6 pb-8 pt-12 text-center">
        <h1 className="text-4xl font-black tracking-tight text-slate-900 sm:text-5xl">
          Engineering Project Showcase
        </h1>
      </header>

      {/* Grid */}
      <section className="mx-auto max-w-6xl px-6 pb-20">
        <ShowcaseClient projects={data} />
      </section>

      <footer className="border-t border-slate-200/70 bg-white/60 py-6 text-center text-xs text-slate-400">
        CADFolio
      </footer>
    </main>
  );
}
