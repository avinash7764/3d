"use client";

import Link from "next/link";
import { useCallback, useEffect, useState } from "react";
import {
  adminFetch,
  clearAdminPassword,
  login as doLogin,
  verifyStoredPassword,
} from "@/lib/adminClient";
import { isDriveUrl, isYouTubeUrl } from "@/lib/links";
import type { ProjectDto } from "@/lib/types";

const MODEL_FORMATS = ["stl", "obj", "igs", "fbx", "glb", "gltf"];

type ProjectForm = {
  title: string;
  description: string;
  category: string;
  tags: string;
  coverImageUrl: string;
};

const emptyProject: ProjectForm = {
  title: "",
  description: "",
  category: "Design",
  tags: "",
  coverImageUrl: "",
};

type MediaForm = {
  kind: string;
  format: string;
  url: string;
  label: string;
};

const emptyMedia: MediaForm = { kind: "model", format: "stl", url: "", label: "" };

export default function AdminPage() {
  const [authed, setAuthed] = useState<boolean | null>(null);
  const [password, setPassword] = useState("");
  const [loginError, setLoginError] = useState("");
  const [signingIn, setSigningIn] = useState(false);

  const [projects, setProjects] = useState<ProjectDto[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState("");
  const [error, setError] = useState("");

  const [newProject, setNewProject] = useState<ProjectForm>(emptyProject);
  const [editId, setEditId] = useState<number | null>(null);
  const [editForm, setEditForm] = useState<ProjectForm>(emptyProject);
  const [mediaForms, setMediaForms] = useState<Record<number, MediaForm>>({});
  const [mediaEditId, setMediaEditId] = useState<number | null>(null);
  const [mediaEdit, setMediaEdit] = useState<{ url: string; label: string }>({ url: "", label: "" });
  const [relock, setRelock] = useState(false);
  const [relockMsg, setRelockMsg] = useState("");
  const [relockPw, setRelockPw] = useState("");
  const [relockErr, setRelockErr] = useState("");

  const flash = (msg: string) => {
    setError("");
    setNotice(msg);
    setTimeout(() => setNotice(""), 2500);
  };
  const fail = (prefix: string, err: string) => {
    setNotice("");
    setError(`${prefix}: ${err}`);
  };

  /**
   * A 401 means the password we hold no longer matches the server. Instead of
   * throwing the user out (and losing whatever they typed), show an inline
   * unlock prompt on top of the dashboard and retry the action afterwards.
   */
  const handleFailure = (prefix: string, res: { error: string; unauthorized: boolean }) => {
    if (res.unauthorized) {
      setRelockMsg(`${prefix}: the admin password was not accepted. Re-enter it to continue.`);
      setRelock(true);
      return;
    }
    fail(prefix, res.error);
  };

  const refresh = useCallback(async () => {
    const res = await adminFetch<{ projects: ProjectDto[] }>("/api/projects");
    if (res.ok) setProjects(res.data.projects || []);
    else fail("Could not load projects", res.error);
    setLoading(false);
  }, []);

  useEffect(() => {
    let active = true;
    verifyStoredPassword().then((ok) => {
      if (active) setAuthed(ok);
    });
    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    if (authed) refresh();
  }, [authed, refresh]);

  async function submitLogin(e: React.FormEvent) {
    e.preventDefault();
    if (!password) {
      setLoginError("Please enter the admin password.");
      return;
    }
    setSigningIn(true);
    const res = await doLogin(password);
    setSigningIn(false);
    if (res.ok) {
      setLoginError("");
      setError("");
      setAuthed(true);
    } else {
      setLoginError(res.error || "Incorrect password.");
    }
  }

  function logout() {
    clearAdminPassword();
    setPassword("");
    setProjects([]);
    setLoginError("");
    setRelock(false);
    setAuthed(false);
  }

  /** Re-enter the password without leaving the dashboard or losing form data. */
  async function submitRelock(e: React.FormEvent) {
    e.preventDefault();
    setRelockErr("");
    const res = await doLogin(relockPw);
    if (res.ok) {
      setRelock(false);
      setRelockPw("");
      setRelockMsg("");
      flash("Unlocked — please repeat the last action");
      await refresh();
    } else {
      setRelockErr(res.error || "Incorrect password.");
    }
  }

  async function createProject(e: React.FormEvent) {
    e.preventDefault();
    if (!newProject.title.trim()) {
      fail("Missing field", "Project title is required.");
      return;
    }
    setBusy(true);
    const res = await adminFetch("/api/projects", {
      method: "POST",
      body: JSON.stringify(newProject),
    });
    setBusy(false);
    if (res.ok) {
      setNewProject(emptyProject);
      flash("Project created");
      await refresh();
    } else {
      handleFailure("Could not create project", res);
    }
  }

  async function duplicateProject(id: number) {
    setBusy(true);
    const res = await adminFetch<{ copiedMedia: number }>(`/api/projects/${id}/duplicate`, {
      method: "POST",
    });
    setBusy(false);
    if (res.ok) {
      flash(`Project duplicated (${res.data.copiedMedia} media items copied)`);
      await refresh();
    } else {
      handleFailure("Could not duplicate project", res);
    }
  }

  async function saveProject(id: number) {
    setBusy(true);
    const res = await adminFetch("/api/projects", {
      method: "PUT",
      body: JSON.stringify({ id, ...editForm }),
    });
    setBusy(false);
    if (res.ok) {
      setEditId(null);
      flash("Project updated");
      await refresh();
    } else {
      handleFailure("Could not update project", res);
    }
  }

  async function deleteProject(id: number) {
    if (!confirm("Delete this project and all its media?")) return;
    const res = await adminFetch(`/api/projects/${id}`, { method: "DELETE" });
    if (res.ok) {
      flash("Project deleted");
      await refresh();
    } else {
      handleFailure("Could not delete project", res);
    }
  }

  const linkCount = (raw: string) => parseLinks(raw).length;

  /** Splits the textarea into individual links (one per line, or comma separated). */
  function parseLinks(raw: string): string[] {
    return raw
      .split(/[\r\n]+|,(?=\s*https?:\/\/)/g)
      .map((l) => l.trim())
      .filter(Boolean);
  }

  async function addMedia(projectId: number) {
    const form = mediaForms[projectId] || emptyMedia;
    const links = parseLinks(form.url);
    if (links.length === 0) {
      fail("Missing link", "Paste a Drive / YouTube / direct link first.");
      return;
    }

    setBusy(true);
    const existing = projects.find((p) => p.id === projectId)?.media.length ?? 0;
    let added = 0;
    const failures: string[] = [];

    // Sequential so ordering stays stable and errors map to the right link.
    for (let i = 0; i < links.length; i++) {
      const res = await adminFetch("/api/media", {
        method: "POST",
        body: JSON.stringify({
          projectId,
          kind: form.kind,
          format: form.kind === "model" ? form.format : "",
          url: links[i],
          label: links.length > 1 && form.label ? `${form.label} ${i + 1}` : form.label,
          sortOrder: existing + i + 1,
        }),
      });
      if (res.ok) {
        added++;
      } else {
        if (res.unauthorized) {
          setBusy(false);
          handleFailure("Could not attach media", res);
          if (added > 0) await refresh();
          return;
        }
        failures.push(`${links[i].slice(0, 48)}… (${res.error})`);
      }
    }
    setBusy(false);

    if (added > 0) {
      setMediaForms((m) => ({ ...m, [projectId]: { ...emptyMedia, kind: form.kind } }));
      flash(added === 1 ? "Media attached" : `${added} media items attached`);
      await refresh();
    }
    if (failures.length > 0) {
      fail(
        `${failures.length} link${failures.length > 1 ? "s" : ""} could not be attached`,
        failures.join(" · ")
      );
    }
  }

  async function saveMedia(id: number, patch: { url: string; label: string }) {
    if (!patch.url.trim()) {
      fail("Missing link", "The media URL cannot be empty.");
      return;
    }
    setBusy(true);
    const res = await adminFetch(`/api/media/${id}`, {
      method: "PUT",
      body: JSON.stringify({ url: patch.url.trim(), label: patch.label }),
    });
    setBusy(false);
    if (res.ok) {
      setMediaEditId(null);
      flash("Media updated");
      await refresh();
    } else {
      handleFailure("Could not update media", res);
    }
  }

  /** Swaps sortOrder with the neighbouring item of the same project. */
  async function moveMedia(project: ProjectDto, index: number, dir: -1 | 1) {
    const list = [...project.media];
    const target = index + dir;
    if (target < 0 || target >= list.length) return;
    const a = list[index];
    const b = list[target];
    setBusy(true);
    const r1 = await adminFetch(`/api/media/${a.id}`, {
      method: "PUT",
      body: JSON.stringify({ sortOrder: target + 1 }),
    });
    const r2 = await adminFetch(`/api/media/${b.id}`, {
      method: "PUT",
      body: JSON.stringify({ sortOrder: index + 1 }),
    });
    setBusy(false);
    if (r1.ok && r2.ok) await refresh();
    else if (!r1.ok) handleFailure("Could not reorder media", r1);
    else if (!r2.ok) handleFailure("Could not reorder media", r2);
  }

  async function deleteMedia(id: number) {
    const res = await adminFetch(`/api/media/${id}`, { method: "DELETE" });
    if (res.ok) {
      flash("Media removed");
      await refresh();
    } else {
      handleFailure("Could not remove media", res);
    }
  }

  function sourceBadge(url: string) {
    if (isDriveUrl(url))
      return <span className="rounded bg-emerald-100 px-1.5 py-0.5 text-[10px] font-bold text-emerald-700">DRIVE</span>;
    if (isYouTubeUrl(url))
      return <span className="rounded bg-red-100 px-1.5 py-0.5 text-[10px] font-bold text-red-700">YOUTUBE</span>;
    return <span className="rounded bg-slate-100 px-1.5 py-0.5 text-[10px] font-bold text-slate-500">URL</span>;
  }

  // ---------- Session gate ----------
  if (authed === null) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-slate-100 text-sm text-slate-400">
        Checking session…
      </main>
    );
  }

  if (!authed) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-gradient-to-b from-indigo-50 to-slate-200 px-4">
        <form
          onSubmit={submitLogin}
          className="w-full max-w-sm rounded-2xl bg-white p-8 shadow-xl ring-1 ring-slate-200"
        >
          <div className="mb-6 text-center">
            <svg className="mx-auto h-10 w-10 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
            </svg>
            <h1 className="mt-3 text-xl font-bold text-slate-900">Admin Login</h1>
          </div>
          <input
            type="password"
            autoFocus
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Password"
            className="w-full rounded-lg border border-slate-300 px-4 py-2.5 text-sm outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200"
          />
          {loginError && <p className="mt-2 text-xs font-medium text-red-600">{loginError}</p>}
          <button
            type="submit"
            disabled={signingIn}
            className="mt-4 w-full rounded-lg bg-indigo-600 py-2.5 text-sm font-semibold text-white transition hover:bg-indigo-700 disabled:opacity-60"
          >
            {signingIn ? "Signing in…" : "Sign in"}
          </button>
          <Link href="/" className="mt-4 block text-center text-xs text-slate-400 hover:text-slate-600">
            ← Back to showcase
          </Link>
        </form>
      </main>
    );
  }

  // ---------- Dashboard ----------
  return (
    <main className="min-h-screen bg-slate-100 pb-20">
      <nav className="border-b border-slate-200 bg-white">
        <div className="mx-auto flex max-w-5xl items-center justify-between px-6 py-4">
          <h1 className="text-lg font-bold text-slate-900">
            CAD<span className="text-indigo-600">Folio</span> · Admin
          </h1>
          <div className="flex items-center gap-2">
            <a
              href="/standalone.html"
              target="_blank"
              rel="noreferrer"
              title="Single-file HTML build with its own admin panel"
              className="rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-sm font-medium text-slate-700 hover:bg-slate-50"
            >
              HTML build
            </a>
            <Link
              href="/"
              className="rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-sm font-medium text-slate-700 hover:bg-slate-50"
            >
              View site
            </Link>
            <button
              onClick={logout}
              className="rounded-lg border border-slate-300 bg-white px-3 py-1.5 text-sm font-medium text-slate-600 hover:bg-slate-50"
            >
              Logout
            </button>
          </div>
        </div>
      </nav>

      {notice && (
        <div className="fixed bottom-6 left-1/2 z-50 -translate-x-1/2 rounded-full bg-slate-900 px-5 py-2 text-sm font-medium text-white shadow-lg">
          {notice}
        </div>
      )}

      {/* Inline unlock — keeps the dashboard and all typed data intact */}
      {relock && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-slate-900/50 p-4">
          <form
            onSubmit={submitRelock}
            className="w-full max-w-sm rounded-2xl bg-white p-6 shadow-2xl"
          >
            <h3 className="text-base font-bold text-slate-900">Confirm admin password</h3>
            <p className="mt-1 text-xs text-slate-500">{relockMsg}</p>
            <input
              type="password"
              autoFocus
              value={relockPw}
              onChange={(e) => setRelockPw(e.target.value)}
              placeholder="Admin password"
              className="mt-4 w-full rounded-lg border border-slate-300 px-4 py-2.5 text-sm outline-none focus:border-indigo-500"
            />
            {relockErr && <p className="mt-2 text-xs font-medium text-red-600">{relockErr}</p>}
            <div className="mt-4 flex gap-2">
              <button
                type="submit"
                className="flex-1 rounded-lg bg-indigo-600 py-2.5 text-sm font-semibold text-white hover:bg-indigo-700"
              >
                Unlock
              </button>
              <button
                type="button"
                onClick={() => setRelock(false)}
                className="rounded-lg border border-slate-300 px-4 py-2.5 text-sm font-semibold text-slate-600 hover:bg-slate-50"
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="mx-auto max-w-5xl space-y-8 px-6 pt-8">
        {error && (
          <div className="flex items-start justify-between gap-4 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
            <span>{error}</span>
            <button onClick={() => setError("")} className="shrink-0 font-bold text-red-400 hover:text-red-600">
              ✕
            </button>
          </div>
        )}

        {/* New project */}
        <section className="rounded-2xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
          <h2 className="mb-4 text-base font-bold text-slate-900">Add New Project</h2>
          <form onSubmit={createProject} className="grid gap-3 sm:grid-cols-2">
            <input
              placeholder="Project title *"
              value={newProject.title}
              onChange={(e) => setNewProject({ ...newProject, title: e.target.value })}
              className="rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none focus:border-indigo-500"
            />
            <input
              placeholder="Category (e.g. Design)"
              value={newProject.category}
              onChange={(e) => setNewProject({ ...newProject, category: e.target.value })}
              className="rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none focus:border-indigo-500"
            />
            <textarea
              placeholder="Description"
              value={newProject.description}
              onChange={(e) => setNewProject({ ...newProject, description: e.target.value })}
              className="rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none focus:border-indigo-500 sm:col-span-2"
              rows={2}
            />
            <input
              placeholder="Tags, comma separated (e.g. CATIA V5, FEA Analysis)"
              value={newProject.tags}
              onChange={(e) => setNewProject({ ...newProject, tags: e.target.value })}
              className="rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none focus:border-indigo-500"
            />
            <input
              placeholder="Cover image URL (Drive link or direct URL)"
              value={newProject.coverImageUrl}
              onChange={(e) => setNewProject({ ...newProject, coverImageUrl: e.target.value })}
              className="rounded-lg border border-slate-300 px-3 py-2 text-sm outline-none focus:border-indigo-500"
            />
            <button
              type="submit"
              disabled={busy}
              className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-semibold text-white transition hover:bg-indigo-700 disabled:opacity-50 sm:col-span-2"
            >
              {busy ? "Saving…" : "Create Project"}
            </button>
          </form>
        </section>

        {loading && <p className="text-sm text-slate-400">Loading projects…</p>}

        {!loading && projects.length === 0 && (
          <p className="rounded-2xl border border-dashed border-slate-300 bg-white/60 p-10 text-center text-sm text-slate-400">
            No projects yet — create your first one above.
          </p>
        )}

        {/* Projects */}
        {projects.map((p) => {
          const mf = mediaForms[p.id] || emptyMedia;
          const editing = editId === p.id;
          return (
            <section key={p.id} className="rounded-2xl bg-white p-6 shadow-sm ring-1 ring-slate-200">
              <div className="flex flex-wrap items-start justify-between gap-3">
                {editing ? (
                  <div className="grid flex-1 gap-2 sm:grid-cols-2">
                    <input
                      value={editForm.title}
                      onChange={(e) => setEditForm({ ...editForm, title: e.target.value })}
                      className="rounded-lg border border-slate-300 px-3 py-2 text-sm"
                      placeholder="Title"
                    />
                    <input
                      value={editForm.category}
                      onChange={(e) => setEditForm({ ...editForm, category: e.target.value })}
                      className="rounded-lg border border-slate-300 px-3 py-2 text-sm"
                      placeholder="Category"
                    />
                    <textarea
                      value={editForm.description}
                      onChange={(e) => setEditForm({ ...editForm, description: e.target.value })}
                      className="rounded-lg border border-slate-300 px-3 py-2 text-sm sm:col-span-2"
                      rows={2}
                      placeholder="Description"
                    />
                    <input
                      value={editForm.tags}
                      onChange={(e) => setEditForm({ ...editForm, tags: e.target.value })}
                      className="rounded-lg border border-slate-300 px-3 py-2 text-sm"
                      placeholder="Tags"
                    />
                    <input
                      value={editForm.coverImageUrl}
                      onChange={(e) => setEditForm({ ...editForm, coverImageUrl: e.target.value })}
                      className="rounded-lg border border-slate-300 px-3 py-2 text-sm"
                      placeholder="Cover image URL"
                    />
                  </div>
                ) : (
                  <div className="min-w-0 flex-1">
                    <h3 className="text-base font-bold text-slate-900">{p.title}</h3>
                    <p className="mt-1 line-clamp-2 text-sm text-slate-500">{p.description}</p>
                    <p className="mt-1 font-mono text-[11px] uppercase tracking-wide text-slate-400">
                      {p.category} {p.tags && `· ${p.tags}`}
                    </p>
                  </div>
                )}
                <div className="flex shrink-0 flex-wrap gap-2">
                  {editing ? (
                    <>
                      <button
                        onClick={() => saveProject(p.id)}
                        className="rounded-lg bg-emerald-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-emerald-700"
                      >
                        Save
                      </button>
                      <button
                        onClick={() => setEditId(null)}
                        className="rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-semibold text-slate-600 hover:bg-slate-50"
                      >
                        Cancel
                      </button>
                    </>
                  ) : (
                    <>
                      <button
                        onClick={() => {
                          setEditId(p.id);
                          setEditForm({
                            title: p.title,
                            description: p.description,
                            category: p.category,
                            tags: p.tags,
                            coverImageUrl: p.coverImageUrl,
                          });
                        }}
                        className="rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-semibold text-slate-600 hover:bg-slate-50"
                      >
                        Edit
                      </button>
                      <button
                        onClick={() => duplicateProject(p.id)}
                        disabled={busy}
                        title="Create a new project as a copy of this one (including all media)"
                        className="flex items-center gap-1 rounded-lg border border-indigo-200 bg-indigo-50 px-3 py-1.5 text-xs font-semibold text-indigo-700 hover:bg-indigo-100 disabled:opacity-50"
                      >
                        <svg className="h-3.5 w-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                          <rect x="9" y="9" width="12" height="12" rx="2" />
                          <path strokeLinecap="round" strokeLinejoin="round" d="M5 15H4a1 1 0 01-1-1V4a1 1 0 011-1h10a1 1 0 011 1v1" />
                        </svg>
                        Duplicate
                      </button>
                      <button
                        onClick={() => deleteProject(p.id)}
                        className="rounded-lg border border-red-200 px-3 py-1.5 text-xs font-semibold text-red-600 hover:bg-red-50"
                      >
                        Delete
                      </button>
                    </>
                  )}
                </div>
              </div>

              {/* Media list */}
              <div className="mt-5 space-y-2">
                {p.media.map((m, mi) => {
                  const rowEditing = mediaEditId === m.id;
                  return (
                    <div
                      key={m.id}
                      className="rounded-lg border border-slate-100 bg-slate-50 px-3 py-2"
                    >
                      <div className="flex items-center gap-3">
                        <span
                          className={`w-14 shrink-0 rounded-md py-1 text-center text-[10px] font-black uppercase ${
                            m.kind === "model"
                              ? "bg-indigo-100 text-indigo-700"
                              : m.kind === "image"
                                ? "bg-amber-100 text-amber-700"
                                : "bg-rose-100 text-rose-700"
                          }`}
                        >
                          {m.kind === "model" ? m.format || "3D" : m.kind}
                        </span>
                        {sourceBadge(m.url)}
                        {rowEditing ? (
                          <span className="flex-1 text-xs font-semibold text-slate-500">
                            Editing…
                          </span>
                        ) : (
                          <span
                            className="min-w-0 flex-1 truncate text-xs text-slate-600"
                            title={m.url}
                          >
                            {m.label ? `${m.label} — ` : ""}
                            {m.url}
                          </span>
                        )}

                        <div className="flex shrink-0 items-center gap-1">
                          <button
                            onClick={() => moveMedia(p, mi, -1)}
                            disabled={busy || mi === 0}
                            title="Move up"
                            className="rounded px-1.5 py-0.5 text-xs text-slate-400 hover:bg-white hover:text-slate-700 disabled:opacity-30"
                          >
                            ▲
                          </button>
                          <button
                            onClick={() => moveMedia(p, mi, 1)}
                            disabled={busy || mi === p.media.length - 1}
                            title="Move down"
                            className="rounded px-1.5 py-0.5 text-xs text-slate-400 hover:bg-white hover:text-slate-700 disabled:opacity-30"
                          >
                            ▼
                          </button>
                          {rowEditing ? (
                            <>
                              <button
                                onClick={() => saveMedia(m.id, mediaEdit)}
                                disabled={busy}
                                className="rounded-md bg-emerald-600 px-2.5 py-1 text-xs font-semibold text-white hover:bg-emerald-700"
                              >
                                Save
                              </button>
                              <button
                                onClick={() => setMediaEditId(null)}
                                className="rounded-md border border-slate-300 px-2.5 py-1 text-xs font-semibold text-slate-600 hover:bg-white"
                              >
                                Cancel
                              </button>
                            </>
                          ) : (
                            <>
                              <button
                                onClick={() => {
                                  setMediaEditId(m.id);
                                  setMediaEdit({ url: m.url, label: m.label });
                                }}
                                className="text-xs font-semibold text-indigo-600 hover:underline"
                              >
                                Edit
                              </button>
                              <button
                                onClick={() => deleteMedia(m.id)}
                                className="text-xs font-semibold text-red-500 hover:underline"
                              >
                                Remove
                              </button>
                            </>
                          )}
                        </div>
                      </div>

                      {rowEditing && (
                        <div className="mt-2 flex flex-wrap gap-2">
                          <input
                            value={mediaEdit.url}
                            onChange={(e) => setMediaEdit({ ...mediaEdit, url: e.target.value })}
                            placeholder="Media URL"
                            className="min-w-[220px] flex-1 rounded-lg border border-slate-300 px-3 py-1.5 text-xs"
                          />
                          <input
                            value={mediaEdit.label}
                            onChange={(e) => setMediaEdit({ ...mediaEdit, label: e.target.value })}
                            placeholder="Label"
                            className="w-44 rounded-lg border border-slate-300 px-3 py-1.5 text-xs"
                          />
                        </div>
                      )}
                    </div>
                  );
                })}
                {p.media.length === 0 && (
                  <p className="text-xs text-slate-400">No media attached yet.</p>
                )}
              </div>

              {/* Add media */}
              <div className="mt-4 rounded-xl border border-dashed border-slate-300 p-4">
                <p className="mb-3 text-xs font-bold uppercase tracking-wide text-slate-400">
                  Attach media (Google Drive / YouTube / direct link)
                </p>
                <div className="flex flex-wrap items-start gap-2">
                  <select
                    value={mf.kind}
                    onChange={(e) =>
                      setMediaForms((s) => ({ ...s, [p.id]: { ...mf, kind: e.target.value } }))
                    }
                    className="rounded-lg border border-slate-300 px-2.5 py-2 text-sm"
                  >
                    <option value="model">3D Model</option>
                    <option value="image">Image</option>
                    <option value="video">Video</option>
                  </select>
                  {mf.kind === "model" && (
                    <select
                      value={mf.format}
                      onChange={(e) =>
                        setMediaForms((s) => ({ ...s, [p.id]: { ...mf, format: e.target.value } }))
                      }
                      className="rounded-lg border border-slate-300 px-2.5 py-2 text-sm uppercase"
                    >
                      {MODEL_FORMATS.map((f) => (
                        <option key={f} value={f}>
                          {f.toUpperCase()}
                        </option>
                      ))}
                    </select>
                  )}
                  <textarea
                    rows={2}
                    placeholder={
                      mf.kind === "image"
                        ? "Paste one or more image links — one per line to add several at once"
                        : mf.kind === "video"
                          ? "YouTube or Drive video link"
                          : "Drive share link or direct URL"
                    }
                    value={mf.url}
                    onChange={(e) =>
                      setMediaForms((s) => ({ ...s, [p.id]: { ...mf, url: e.target.value } }))
                    }
                    className="min-w-[240px] flex-1 resize-y rounded-lg border border-slate-300 px-3 py-2 text-sm"
                  />
                  <input
                    placeholder="Label (optional)"
                    value={mf.label}
                    onChange={(e) =>
                      setMediaForms((s) => ({ ...s, [p.id]: { ...mf, label: e.target.value } }))
                    }
                    className="w-40 rounded-lg border border-slate-300 px-3 py-2 text-sm"
                  />
                  <button
                    onClick={() => addMedia(p.id)}
                    disabled={busy || !mf.url.trim()}
                    className="rounded-lg bg-slate-900 px-4 py-2 text-sm font-semibold text-white transition hover:bg-slate-700 disabled:opacity-40"
                  >
                    {busy ? "Attaching…" : linkCount(mf.url) > 1 ? `Attach ${linkCount(mf.url)}` : "Attach"}
                  </button>
                </div>
                <p className="mt-2 text-[11px] text-slate-400">
                  Tip: paste multiple links (one per line) to add several images at once. Drive files
                  must be shared as “Anyone with the link”. Model formats: STL, OBJ, IGS/IGES, FBX,
                  GLB, GLTF.
                </p>
              </div>

            </section>
          );
        })}
      </div>
    </main>
  );
}
