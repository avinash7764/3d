import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "CADFolio — 3D Engineering Project Showcase",
  description:
    "Showcase engineering projects with interactive 3D CAD models (STL, OBJ, IGS, FBX, GLB, GLTF), images and videos captured from Google Drive and YouTube links.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-slate-100 text-slate-900 antialiased">{children}</body>
    </html>
  );
}
