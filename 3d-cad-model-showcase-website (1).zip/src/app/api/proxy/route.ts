import { NextRequest, NextResponse } from "next/server";
import { extractDriveId } from "@/lib/links";

export const dynamic = "force-dynamic";

const BROWSER_UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36";

/**
 * Server-side media proxy. Streams Google Drive downloads (and other remote
 * files) to the browser so 3D model loaders and <img> tags never face CORS
 * or hot-linking restrictions.
 */
export async function GET(req: NextRequest) {
  const src = req.nextUrl.searchParams.get("src");
  if (!src || !/^https?:\/\//i.test(src)) {
    return NextResponse.json({ error: "src query param (http/https) required" }, { status: 400 });
  }

  try {
    let upstream = await fetch(src, {
      redirect: "follow",
      headers: { "User-Agent": BROWSER_UA },
    });

    // Google Drive returns an HTML "virus scan warning" page for large files.
    const contentType = upstream.headers.get("content-type") || "";
    const driveId = extractDriveId(src);
    if (driveId && contentType.includes("text/html")) {
      const confirmUrl = `https://drive.usercontent.google.com/download?id=${driveId}&export=download&confirm=t`;
      upstream = await fetch(confirmUrl, {
        redirect: "follow",
        headers: { "User-Agent": BROWSER_UA },
      });
    }

    if (!upstream.ok || !upstream.body) {
      return NextResponse.json(
        { error: `Upstream responded ${upstream.status}` },
        { status: 502 }
      );
    }

    const headers = new Headers();
    headers.set("content-type", upstream.headers.get("content-type") || "application/octet-stream");
    const len = upstream.headers.get("content-length");
    if (len) headers.set("content-length", len);
    headers.set("cache-control", "public, max-age=3600");
    headers.set("access-control-allow-origin", "*");

    return new Response(upstream.body, { status: 200, headers });
  } catch (err) {
    return NextResponse.json(
      { error: `Proxy fetch failed: ${err instanceof Error ? err.message : "unknown"}` },
      { status: 502 }
    );
  }
}
