import { NextRequest, NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { mediaItems } from "@/db/schema";
import { isAdmin } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  if (!(await isAdmin(req))) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const { id } = await params;
  await db.delete(mediaItems).where(eq(mediaItems.id, Number(id)));
  return NextResponse.json({ ok: true });
}

export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  if (!(await isAdmin(req))) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const { id } = await params;
  const body = await req.json().catch(() => ({}));
  const [row] = await db
    .update(mediaItems)
    .set({
      kind: typeof body.kind === "string" ? body.kind : undefined,
      format: typeof body.format === "string" ? body.format.toLowerCase() : undefined,
      url: typeof body.url === "string" ? body.url.trim() : undefined,
      label: typeof body.label === "string" ? body.label : undefined,
      sortOrder: Number.isFinite(body.sortOrder) ? Number(body.sortOrder) : undefined,
    })
    .where(eq(mediaItems.id, Number(id)))
    .returning();
  return NextResponse.json({ media: row });
}
