import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { mediaItems } from "@/db/schema";
import { isAdmin } from "@/lib/auth";

export const dynamic = "force-dynamic";

const KINDS = ["model", "image", "video"];

export async function POST(req: NextRequest) {
  if (!(await isAdmin(req))) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const body = await req.json().catch(() => null);
  if (!body) return NextResponse.json({ error: "Bad request" }, { status: 400 });
  const projectId = Number(body.projectId);
  const kind = String(body.kind || "");
  const url = String(body.url || "").trim();
  if (!projectId || !KINDS.includes(kind) || !url) {
    return NextResponse.json(
      { error: "projectId, kind (model|image|video) and url are required" },
      { status: 400 }
    );
  }
  const [row] = await db
    .insert(mediaItems)
    .values({
      projectId,
      kind,
      url,
      format: typeof body.format === "string" ? body.format.toLowerCase() : "",
      label: typeof body.label === "string" ? body.label : "",
      sortOrder: Number.isFinite(body.sortOrder) ? Number(body.sortOrder) : 0,
    })
    .returning();
  return NextResponse.json({ media: row }, { status: 201 });
}
