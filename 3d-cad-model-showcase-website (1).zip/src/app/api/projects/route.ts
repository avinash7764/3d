import { NextRequest, NextResponse } from "next/server";
import { asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { mediaItems, projects } from "@/db/schema";
import { isAdmin } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET() {
  const projectRows = await db
    .select()
    .from(projects)
    .orderBy(asc(projects.sortOrder), asc(projects.id));
  const mediaRows = await db
    .select()
    .from(mediaItems)
    .orderBy(asc(mediaItems.sortOrder), asc(mediaItems.id));

  const data = projectRows.map((p) => ({
    ...p,
    media: mediaRows.filter((m) => m.projectId === p.id),
  }));
  return NextResponse.json({ projects: data });
}

export async function POST(req: NextRequest) {
  if (!(await isAdmin(req))) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const body = await req.json().catch(() => null);
  if (!body || typeof body.title !== "string" || !body.title.trim()) {
    return NextResponse.json({ error: "Title is required" }, { status: 400 });
  }
  const [row] = await db
    .insert(projects)
    .values({
      title: body.title.trim(),
      description: typeof body.description === "string" ? body.description : "",
      category: typeof body.category === "string" && body.category ? body.category : "Design",
      tags: typeof body.tags === "string" ? body.tags : "",
      coverImageUrl: typeof body.coverImageUrl === "string" ? body.coverImageUrl : "",
      sortOrder: Number.isFinite(body.sortOrder) ? Number(body.sortOrder) : 0,
    })
    .returning();
  return NextResponse.json({ project: row }, { status: 201 });
}

export async function PUT(req: NextRequest) {
  if (!(await isAdmin(req))) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const body = await req.json().catch(() => null);
  const id = Number(body?.id);
  if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });
  const [row] = await db
    .update(projects)
    .set({
      title: typeof body.title === "string" ? body.title.trim() : undefined,
      description: typeof body.description === "string" ? body.description : undefined,
      category: typeof body.category === "string" ? body.category : undefined,
      tags: typeof body.tags === "string" ? body.tags : undefined,
      coverImageUrl: typeof body.coverImageUrl === "string" ? body.coverImageUrl : undefined,
      sortOrder: Number.isFinite(body.sortOrder) ? Number(body.sortOrder) : undefined,
    })
    .where(eq(projects.id, id))
    .returning();
  return NextResponse.json({ project: row });
}
