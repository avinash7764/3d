import { NextRequest, NextResponse } from "next/server";
import { asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { mediaItems, projects } from "@/db/schema";
import { isAdmin } from "@/lib/auth";

export const dynamic = "force-dynamic";

/** Duplicates a project together with all of its attached media items. */
export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  if (!(await isAdmin(req))) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
  const { id } = await params;
  const sourceId = Number(id);
  if (!sourceId) return NextResponse.json({ error: "Invalid id" }, { status: 400 });

  const [source] = await db.select().from(projects).where(eq(projects.id, sourceId));
  if (!source) return NextResponse.json({ error: "Project not found" }, { status: 404 });

  const [copy] = await db
    .insert(projects)
    .values({
      title: `${source.title} (Copy)`,
      description: source.description,
      category: source.category,
      tags: source.tags,
      coverImageUrl: source.coverImageUrl,
      sortOrder: source.sortOrder + 1,
    })
    .returning();

  const media = await db
    .select()
    .from(mediaItems)
    .where(eq(mediaItems.projectId, sourceId))
    .orderBy(asc(mediaItems.sortOrder), asc(mediaItems.id));

  if (media.length > 0) {
    await db.insert(mediaItems).values(
      media.map((m) => ({
        projectId: copy.id,
        kind: m.kind,
        format: m.format,
        url: m.url,
        label: m.label,
        sortOrder: m.sortOrder,
      }))
    );
  }

  return NextResponse.json({ project: copy, copiedMedia: media.length }, { status: 201 });
}
