import { NextRequest, NextResponse } from "next/server";
import { adminPassword, isAdmin } from "@/lib/auth";

export const dynamic = "force-dynamic";

/** Verifies whether the password sent on this request is valid. */
export async function GET(req: NextRequest) {
  return NextResponse.json({ authenticated: await isAdmin(req) });
}

/** Password check used by the login form. No session is created. */
export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => ({}));
  if (typeof body.password === "string" && body.password === adminPassword()) {
    return NextResponse.json({ ok: true });
  }
  return NextResponse.json({ ok: false, error: "Invalid password" }, { status: 401 });
}
