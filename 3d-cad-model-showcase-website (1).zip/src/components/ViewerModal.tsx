"use client";

import dynamic from "next/dynamic";
import { useEffect, useState } from "react";
import { resolveAssetSrc, shortDriveLabel, videoEmbedUrl } from "@/lib/links";
import type { MediaItemDto, ProjectDto, ViewerTab } from "@/lib/types";

const ModelViewer = dynamic(() => import("./ModelViewer"), {
  ssr: false,
  loading: () => (
    <div className="flex h-full items-center justify-center text-sm text-slate-400">
      Initializing WebGL viewer…
    </div>
  ),
});

type Props = {
  project: ProjectDto;
  initialTab: ViewerTab;
  onClose: () => void;
};

function TabButton({
  active,
  onClick,
  icon,
  label,
  badge,
}: {
  active: boolean;
  onClick: () => void;
  icon: React.ReactNode;
  label: string;
  badge?: number;
}) {
  return (
    <button
      onClick={onClick}
      className={`flex items-center gap-2 rounded-full px-4 py-2 text-sm font-semibold transition ${
        active
          ? "bg-indigo-600 text-white shadow ring-2 ring-indigo-900/60"
          : "text-slate-600 hover:text-slate-900"
      }`}
    >
      {icon}
      {label}
      {badge !== undefined && badge > 0 && (
        <span
          className={`rounded-full px-2 py-0.5 text-xs font-bold ${
            active ? "bg-white/20 text-white" : "bg-slate-200 text-slate-600"
          }`}
        >
          {badge}
        </span>
      )}
    </button>
  );
}

export default function ViewerModal({ project, initialTab, onClose }: Props) {
  const models = project.media.filter((m) => m.kind === "model");
  const images = project.media.filter((m) => m.kind === "image");
  const videos = project.media.filter((m) => m.kind === "video");

  const [tab, setTab] = useState<ViewerTab>(initialTab);
  const [activeModel, setActiveModel] = useState(0);
  const [activeImage, setActiveImage] = useState(0);
  const [activeVideo, setActiveVideo] = useState(0);

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", handler);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", handler);
      document.body.style.overflow = "";
    };
  }, [onClose]);

  const model: MediaItemDto | undefined = models[activeModel];
  const video: MediaItemDto | undefined = videos[activeVideo];

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-white">
      {/* Header */}
      <header className="flex items-center justify-between gap-3 border-b border-slate-200 bg-white px-4 py-3 shadow-sm">
        <div className="flex min-w-0 items-center gap-2.5">
          <svg className="h-6 w-6 shrink-0 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M12 3l9 5-9 5-9-5 9-5zM3 13l9 5 9-5M3 17l9 5 9-5" />
          </svg>
          <h2 className="truncate text-base font-bold text-slate-900">{project.title}</h2>
        </div>

        <div className="flex items-center gap-1 rounded-full bg-slate-100 p-1 shadow-inner">
          <TabButton
            active={tab === "model"}
            onClick={() => setTab("model")}
            label="3D Model"
            icon={
              <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M12 3l9 5-9 5-9-5 9-5zM3 13l9 5 9-5" />
              </svg>
            }
          />
          <TabButton
            active={tab === "images"}
            onClick={() => setTab("images")}
            label="Images"
            badge={images.length}
            icon={
              <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <rect x="3" y="5" width="18" height="14" rx="2" />
                <path strokeLinecap="round" strokeLinejoin="round" d="M3 15l5-4 4 3 3-2 6 4" />
                <circle cx="9" cy="9" r="1" fill="currentColor" stroke="none" />
              </svg>
            }
          />
          <TabButton
            active={tab === "video"}
            onClick={() => setTab("video")}
            label="Video"
            icon={
              <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <rect x="3" y="6" width="13" height="12" rx="2" />
                <path strokeLinecap="round" strokeLinejoin="round" d="M16 10l5-3v10l-5-3" />
              </svg>
            }
          />
        </div>

        <button
          onClick={onClose}
          className="rounded-lg border border-slate-200 p-2 text-slate-500 transition hover:bg-slate-100 hover:text-slate-900"
          aria-label="Close viewer"
        >
          <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>
      </header>

      {/* Body */}
      <div className="min-h-0 flex-1 overflow-hidden">
        {/* ------- 3D MODEL TAB ------- */}
        {tab === "model" && (
          <div className="flex h-full flex-col">
            {models.length > 1 && (
              <div className="flex flex-wrap items-center gap-2 border-b border-slate-100 bg-slate-50 px-4 py-2">
                <span className="text-xs font-semibold uppercase tracking-wide text-slate-400">Format:</span>
                {models.map((m, i) => (
                  <button
                    key={m.id}
                    onClick={() => setActiveModel(i)}
                    className={`rounded-md px-2.5 py-1 text-xs font-bold uppercase transition ${
                      i === activeModel
                        ? "bg-indigo-600 text-white"
                        : "bg-white text-slate-600 ring-1 ring-slate-200 hover:bg-slate-100"
                    }`}
                  >
                    {m.format || m.label || `Model ${i + 1}`}
                  </button>
                ))}
              </div>
            )}
            {model ? (
              <ModelViewer
                key={model.id}
                url={model.url}
                format={model.format}
                label={model.label}
              />
            ) : (
              <EmptyState label="No 3D model attached to this project yet." />
            )}
          </div>
        )}

        {/* ------- IMAGES TAB ------- */}
        {tab === "images" && (
          <div className="flex h-full">
            {images.length > 0 ? (
              <>
                <aside className="flex w-28 shrink-0 flex-col gap-3 overflow-y-auto border-r border-slate-100 p-3">
                  {images.map((img, i) => (
                    <button
                      key={img.id}
                      onClick={() => setActiveImage(i)}
                      className={`overflow-hidden rounded-lg border-2 transition ${
                        i === activeImage
                          ? "border-slate-900 shadow-md"
                          : "border-slate-200 opacity-70 hover:opacity-100"
                      }`}
                    >
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img
                        src={resolveAssetSrc(img.url)}
                        alt={img.label || `Image ${i + 1}`}
                        className="aspect-[4/3] w-full object-cover"
                        loading="lazy"
                      />
                    </button>
                  ))}
                </aside>
                <div className="flex min-w-0 flex-1 flex-col items-center justify-center p-6">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={resolveAssetSrc(images[activeImage].url)}
                    alt={images[activeImage].label || "Project image"}
                    className="max-h-full max-w-full rounded-lg object-contain shadow-lg"
                  />
                  {images[activeImage].label && (
                    <p className="mt-3 text-sm font-medium text-slate-600">
                      {images[activeImage].label}
                    </p>
                  )}
                </div>
              </>
            ) : (
              <EmptyState label="No images attached to this project yet." />
            )}
          </div>
        )}

        {/* ------- VIDEO TAB ------- */}
        {tab === "video" && (
          <div className="flex h-full flex-col items-center justify-center gap-4 bg-slate-50 p-6">
            {video ? (
              <div className="flex w-full max-w-5xl flex-col overflow-hidden rounded-xl bg-[#0b1023] shadow-2xl ring-1 ring-slate-900/40">
                <div className="aspect-video w-full">
                  {(() => {
                    const embed = videoEmbedUrl(video.url);
                    if (embed) {
                      return (
                        <iframe
                          src={embed}
                          className="h-full w-full"
                          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; fullscreen"
                          allowFullScreen
                          title={video.label || "Project video"}
                        />
                      );
                    }
                    return (
                      <video
                        src={resolveAssetSrc(video.url)}
                        controls
                        className="h-full w-full"
                      />
                    );
                  })()}
                </div>
                <div className="flex items-center justify-between gap-3 border-t border-white/10 px-5 py-3">
                  <p className="truncate text-sm font-semibold text-white">
                    {video.label || shortDriveLabel(video.url)}
                  </p>
                  {videos.length > 1 && (
                    <div className="flex gap-1.5">
                      {videos.map((v, i) => (
                        <button
                          key={v.id}
                          onClick={() => setActiveVideo(i)}
                          className={`rounded-md px-2.5 py-1 text-xs font-bold ${
                            i === activeVideo
                              ? "bg-indigo-500 text-white"
                              : "bg-white/10 text-slate-300 hover:bg-white/20"
                          }`}
                        >
                          {i + 1}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ) : (
              <EmptyState label="No video attached to this project yet." />
            )}
          </div>
        )}
      </div>
    </div>
  );
}

function EmptyState({ label }: { label: string }) {
  return (
    <div className="flex h-full w-full flex-col items-center justify-center gap-3 text-slate-400">
      <svg className="h-12 w-12" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v3m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
      </svg>
      <p className="text-sm">{label}</p>
      <p className="text-xs">Attach media from the Admin Panel.</p>
    </div>
  );
}
