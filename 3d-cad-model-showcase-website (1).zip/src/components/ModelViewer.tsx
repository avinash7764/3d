"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { detectModelFormat, resolveAssetSrc } from "@/lib/links";

type Props = {
  url: string;
  format?: string;
  label?: string;
};

type ViewerHandles = {
  dispose: () => void;
  setAutoRotate: (v: boolean) => void;
  setWireframe: (v: boolean) => void;
  resetView: () => void;
};

declare global {
  interface Window {
    occtimportjs?: (opts?: { locateFile?: (f: string) => string }) => Promise<unknown>;
  }
}

const OCCT_CDN = "https://cdn.jsdelivr.net/npm/occt-import-js@0.0.23/dist";

async function loadOcct(): Promise<unknown> {
  if (!window.occtimportjs) {
    await new Promise<void>((resolve, reject) => {
      const s = document.createElement("script");
      s.src = `${OCCT_CDN}/occt-import-js.js`;
      s.onload = () => resolve();
      s.onerror = () => reject(new Error("Failed to load IGES converter (occt-import-js)"));
      document.head.appendChild(s);
    });
  }
  if (!window.occtimportjs) throw new Error("IGES converter unavailable");
  return window.occtimportjs({ locateFile: (f: string) => `${OCCT_CDN}/${f}` });
}

export default function ModelViewer({ url, format, label }: Props) {
  const containerRef = useRef<HTMLDivElement>(null);
  const handlesRef = useRef<ViewerHandles | null>(null);
  const [status, setStatus] = useState<string>("Loading model…");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string>("");
  const [autoRotate, setAutoRotateState] = useState(true);
  const [wireframe, setWireframeState] = useState(false);

  const autoRotateRef = useRef(autoRotate);
  const wireframeRef = useRef(wireframe);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;
    let cancelled = false;

    async function init() {
      setError("");
      setLoading(true);
      setStatus("Loading model…");
      const THREE = await import("three");
      const { OrbitControls } = await import("three/examples/jsm/controls/OrbitControls.js");

      const fmt = detectModelFormat(url, format, label);
      if (!fmt) {
        setError("Unknown model format. Supported: STL, OBJ, IGS, FBX, GLB, GLTF.");
        setStatus("");
        setLoading(false);
        return;
      }

      const src = resolveAssetSrc(url);

      // --- scene ------------------------------------------------------
      const scene = new THREE.Scene();
      scene.background = new THREE.Color(0xffffff);

      const camera = new THREE.PerspectiveCamera(45, 1, 0.01, 5000);
      camera.position.set(2.5, 1.8, 3);

      const renderer = new THREE.WebGLRenderer({ antialias: true });
      renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
      if (!container || cancelled) return;
      container.appendChild(renderer.domElement);

      const controls = new OrbitControls(camera, renderer.domElement);
      controls.enableDamping = true;
      controls.autoRotate = autoRotateRef.current;
      controls.autoRotateSpeed = 2;

      scene.add(new THREE.HemisphereLight(0xffffff, 0x444466, 1.1));
      const dir = new THREE.DirectionalLight(0xffffff, 1.6);
      dir.position.set(5, 8, 6);
      scene.add(dir);
      const dir2 = new THREE.DirectionalLight(0x8888ff, 0.5);
      dir2.position.set(-6, -4, -5);
      scene.add(dir2);

      const resize = () => {
        if (!container) return;
        const w = container.clientWidth || 1;
        const h = container.clientHeight || 1;
        renderer.setSize(w, h);
        camera.aspect = w / h;
        camera.updateProjectionMatrix();
      };
      resize();
      const ro = new ResizeObserver(resize);
      ro.observe(container);

      let frame = 0;
      const animate = () => {
        frame = requestAnimationFrame(animate);
        controls.update();
        renderer.render(scene, camera);
      };
      animate();

      const materials: { wireframe: boolean; needsUpdate: boolean }[] = [];
      const defaultMaterial = () =>
        new THREE.MeshPhongMaterial({
          color: 0x6366f1,
          specular: 0x222233,
          shininess: 60,
          side: THREE.DoubleSide,
        });

      const registerMaterials = (object: import("three").Object3D) => {
        object.traverse((child) => {
          const mesh = child as import("three").Mesh;
          if (mesh.isMesh) {
            const mats = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
            mats.forEach((m) => {
              const mm = m as unknown as { wireframe?: boolean; side?: number };
              if ("wireframe" in mm || mm.wireframe !== undefined) {
                materials.push(m as unknown as { wireframe: boolean; needsUpdate: boolean });
              } else {
                materials.push(m as unknown as { wireframe: boolean; needsUpdate: boolean });
              }
            });
          }
        });
      };

      const countVertices = (object: import("three").Object3D) => {
        let count = 0;
        object.traverse((child) => {
          const mesh = child as import("three").Mesh;
          if (mesh.isMesh && mesh.geometry) {
            const pos = mesh.geometry.getAttribute("position");
            if (pos) count += pos.count;
          }
        });
        return count;
      };

      const fitAndAdd = (object: import("three").Object3D) => {
        const box = new THREE.Box3().setFromObject(object);
        const size = box.getSize(new THREE.Vector3());
        const center = box.getCenter(new THREE.Vector3());
        const maxDim = Math.max(size.x, size.y, size.z) || 1;
        const scale = 2 / maxDim;
        object.position.sub(center);
        const group = new THREE.Group();
        group.add(object);
        group.scale.setScalar(scale);
        scene.add(group);
        camera.position.set(2.2, 1.6, 2.8);
        controls.target.set(0, 0, 0);
        controls.update();
      };

      const applyWireframe = (v: boolean) => {
        materials.forEach((m) => {
          m.wireframe = v;
          m.needsUpdate = true;
        });
      };

      handlesRef.current = {
        dispose: () => {
          cancelAnimationFrame(frame);
          ro.disconnect();
          controls.dispose();
          renderer.dispose();
          renderer.domElement.remove();
        },
        setAutoRotate: (v) => {
          controls.autoRotate = v;
        },
        setWireframe: (v) => applyWireframe(v),
        resetView: () => {
          camera.position.set(2.2, 1.6, 2.8);
          controls.target.set(0, 0, 0);
          controls.update();
        },
      };

      // --- load model --------------------------------------------------
      try {
        let root: import("three").Object3D | null = null;

        if (fmt === "stl") {
          const { STLLoader } = await import("three/examples/jsm/loaders/STLLoader.js");
          const geometry = await new STLLoader().loadAsync(src);
          geometry.computeVertexNormals();
          root = new THREE.Mesh(geometry, defaultMaterial());
        } else if (fmt === "obj") {
          const { OBJLoader } = await import("three/examples/jsm/loaders/OBJLoader.js");
          const group = await new OBJLoader().loadAsync(src);
          group.traverse((child) => {
            const mesh = child as import("three").Mesh;
            if (mesh.isMesh) mesh.material = defaultMaterial();
          });
          root = group;
        } else if (fmt === "fbx") {
          const { FBXLoader } = await import("three/examples/jsm/loaders/FBXLoader.js");
          root = await new FBXLoader().loadAsync(src);
        } else if (fmt === "glb" || fmt === "gltf") {
          const { GLTFLoader } = await import("three/examples/jsm/loaders/GLTFLoader.js");
          const gltf = await new GLTFLoader().loadAsync(src);
          root = gltf.scene;
        } else if (fmt === "igs" || fmt === "iges") {
          setStatus("Loading IGES kernel (WASM)…");
          const occt = (await loadOcct()) as {
            ReadIgesFile: (
              buffer: Uint8Array,
              params: null
            ) => {
              success: boolean;
              meshes: {
                attributes: { position: { array: number[] }; normal?: { array: number[] } };
                index?: { array: number[] };
              }[];
            };
          };
          const resp = await fetch(src);
          if (!resp.ok) throw new Error(`Failed to download file (${resp.status})`);
          const buffer = new Uint8Array(await resp.arrayBuffer());
          setStatus("Tessellating IGES geometry…");
          const result = occt.ReadIgesFile(buffer, null);
          if (!result.success || !result.meshes.length) {
            throw new Error("IGES file could not be tessellated");
          }
          const group = new THREE.Group();
          for (const m of result.meshes) {
            const geometry = new THREE.BufferGeometry();
            geometry.setAttribute(
              "position",
              new THREE.Float32BufferAttribute(m.attributes.position.array, 3)
            );
            if (m.attributes.normal) {
              geometry.setAttribute(
                "normal",
                new THREE.Float32BufferAttribute(m.attributes.normal.array, 3)
              );
            }
            if (m.index) geometry.setIndex(m.index.array);
            if (!m.attributes.normal) geometry.computeVertexNormals();
            group.add(new THREE.Mesh(geometry, defaultMaterial()));
          }
          root = group;
        }

        if (!root) throw new Error("Unsupported format");
        if (cancelled) return;

        registerMaterials(root);
        fitAndAdd(root);
        applyWireframe(wireframeRef.current);
        const vertices = countVertices(root);
        setStatus(
          `Loaded ${fmt.toUpperCase()} model (${vertices.toLocaleString()} vertices)!`
        );
        setLoading(false);
      } catch (e) {
        if (!cancelled) {
          setError(
            e instanceof Error
              ? `Could not load model: ${e.message}. Make sure the Drive link is shared as "Anyone with the link".`
              : "Could not load model."
          );
          setStatus("");
          setLoading(false);
        }
      }
    }

    // Safety net: if anything above the inner try/catch rejects (e.g. a failed
    // dynamic import), still clear the overlay instead of spinning forever.
    init().catch((e: unknown) => {
      if (cancelled) return;
      setError(
        e instanceof Error ? `Viewer failed to start: ${e.message}` : "Viewer failed to start."
      );
      setStatus("");
      setLoading(false);
    });

    return () => {
      cancelled = true;
      setLoading(false);
      handlesRef.current?.dispose();
      handlesRef.current = null;
    };
  }, [url, format, label]);

  const toggleAutoRotate = useCallback(() => {
    setAutoRotateState((v) => {
      const next = !v;
      autoRotateRef.current = next;
      handlesRef.current?.setAutoRotate(next);
      return next;
    });
  }, []);

  const toggleWireframe = useCallback(() => {
    setWireframeState((v) => {
      const next = !v;
      wireframeRef.current = next;
      handlesRef.current?.setWireframe(next);
      return next;
    });
  }, []);

  const resetView = useCallback(() => handlesRef.current?.resetView(), []);

  return (
    <div className="flex h-full w-full flex-col">
      <div ref={containerRef} className="relative min-h-0 flex-1 overflow-hidden">
        {error && (
          <div className="absolute inset-0 z-10 flex items-center justify-center bg-white/90 p-8">
            <div className="max-w-md rounded-xl border border-red-200 bg-red-50 p-5 text-center text-sm text-red-700">
              {error}
            </div>
          </div>
        )}
        {!error && loading && (
          <div className="pointer-events-none absolute inset-0 z-10 flex items-center justify-center bg-white/60 transition-opacity duration-300">
            <div className="flex items-center gap-3 rounded-full bg-slate-900/85 px-5 py-2.5 text-sm text-white shadow-lg">
              <span className="h-3 w-3 animate-spin rounded-full border-2 border-indigo-300 border-t-transparent" />
              {status || "Loading model…"}
            </div>
          </div>
        )}
      </div>

      <div className="border-t border-slate-200 bg-white px-4 py-3">
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={toggleAutoRotate}
            className={`flex items-center gap-2 rounded-lg border px-3.5 py-2 text-sm font-medium transition ${
              autoRotate
                ? "border-indigo-300 bg-indigo-50 text-indigo-600"
                : "border-slate-200 bg-white text-slate-700 hover:bg-slate-50"
            }`}
          >
            <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M4 4v5h5M20 20v-5h-5M4 9a8 8 0 0114-3m2 9a8 8 0 01-14 3" />
            </svg>
            Auto Rotate
          </button>
          <button
            onClick={toggleWireframe}
            className={`flex items-center gap-2 rounded-lg border px-3.5 py-2 text-sm font-medium transition ${
              wireframe
                ? "border-indigo-300 bg-indigo-50 text-indigo-600"
                : "border-slate-200 bg-white text-slate-700 hover:bg-slate-50"
            }`}
          >
            <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M12 3l7 4v10l-7 4-7-4V7l7-4z" />
            </svg>
            Wireframe
          </button>
          <button
            onClick={resetView}
            className="flex items-center gap-2 rounded-lg border border-slate-200 bg-white px-3.5 py-2 text-sm font-medium text-slate-700 transition hover:bg-slate-50"
          >
            <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M9 15L3 9m0 0l6-6M3 9h12a6 6 0 010 12h-3" />
            </svg>
            Reset View
          </button>
          <div className="ml-auto text-xs text-slate-400" title="Drag to rotate • Scroll to zoom • Right-drag to pan">
            <span className="inline-flex h-7 w-7 items-center justify-center rounded-full bg-slate-900 text-white">?</span>
          </div>
        </div>
        <p className="mt-2 text-center text-xs text-slate-500">{error ? "" : status}</p>
      </div>
    </div>
  );
}
