"use client";

import { useState } from "react";
import { resolveAssetSrc } from "@/lib/links";
import type { ProjectDto, ViewerTab } from "@/lib/types";
import ViewerModal from "./ViewerModal";

export default function ShowcaseClient({ projects }: { projects: ProjectDto[] }) {
  const [open, setOpen] = useState<{ project: ProjectDto; tab: ViewerTab } | null>(null);

  return (
    <>
      <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
        {projects.map((p) => (
          <ProjectCard key={p.id} project={p} onOpen={(tab) => setOpen({ project: p, tab })} />
        ))}
      </div>
      {projects.length === 0 && (
        <div className="rounded-2xl border border-dashed border-slate-300 bg-white/60 p-16 text-center">
          <p className="text-lg font-semibold text-slate-600">No projects yet</p>
          <p className="mt-1 text-sm text-slate-400">
            Head to the <a href="/admin" className="text-indigo-600 underline">Admin Panel</a> to add
            your first project with Drive &amp; YouTube links.
          </p>
        </div>
      )}
      {open && (
        <ViewerModal
          project={open.project}
          initialTab={open.tab}
          onClose={() => setOpen(null)}
        />
      )}
    </>
  );
}

function ProjectCard({
  project,
  onOpen,
}: {
  project: ProjectDto;
  onOpen: (tab: ViewerTab) => void;
}) {
  const models = project.media.filter((m) => m.kind === "model").length;
  const images = project.media.filter((m) => m.kind === "image").length;
  const videos = project.media.filter((m) => m.kind === "video").length;
  const tags = project.tags.split(",").map((t) => t.trim()).filter(Boolean);

  return (
    <article className="group flex flex-col overflow-hidden rounded-2xl bg-white shadow-md ring-1 ring-slate-200/60 transition hover:-translate-y-1 hover:shadow-xl">
      {/* Cover */}
      <div className="relative h-44 overflow-hidden bg-[#0b1023]">
        {project.coverImageUrl ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={resolveAssetSrc(project.coverImageUrl)}
            alt={project.title}
            className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
            loading="lazy"
          />
        ) : (
          <div className="flex h-full items-center justify-center">
            <svg className="h-14 w-14 text-indigo-500/40" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M12 3l9 5-9 5-9-5 9-5zM3 13l9 5 9-5" />
            </svg>
          </div>
        )}
        <span className="absolute left-3 top-3 rounded-md bg-amber-50 px-2.5 py-1 font-mono text-[11px] font-bold uppercase tracking-wider text-slate-800 shadow">
          {project.category || "Design"}
        </span>
        {models > 0 && (
          <span className="absolute right-3 top-3 flex items-center gap-1.5 rounded-md bg-slate-900/90 px-2.5 py-1 font-mono text-[11px] font-bold uppercase tracking-wider text-slate-100 shadow">
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />
            3D Digital Twin
          </span>
        )}
      </div>

      {/* Body */}
      <div className="flex flex-1 flex-col gap-3 p-5">
        <h3 className="text-xl font-bold text-slate-900">{project.title}</h3>
        <p className="flex-1 text-sm leading-relaxed text-slate-600">{project.description}</p>
        {tags.length > 0 && (
          <div className="flex flex-wrap gap-2">
            {tags.map((t) => (
              <span
                key={t}
                className="rounded-md border border-amber-300 bg-amber-50 px-2 py-1 font-mono text-[11px] font-bold uppercase tracking-wide text-slate-700"
              >
                {t}
              </span>
            ))}
          </div>
        )}
      </div>

      {/* Tab launcher */}
      <div className="px-4 pb-4">
        <div className="flex items-center gap-1 rounded-full border border-slate-200 bg-slate-50 p-1.5">
          <button
            onClick={() => onOpen("model")}
            disabled={models === 0}
            className="flex flex-1 items-center justify-center gap-1.5 rounded-full bg-indigo-600 px-3 py-2 text-sm font-semibold text-white shadow transition hover:bg-indigo-700 disabled:cursor-not-allowed disabled:bg-slate-200 disabled:text-slate-400 disabled:shadow-none"
          >
            <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M12 3l9 5-9 5-9-5 9-5zM3 13l9 5 9-5" />
            </svg>
            3D Model
          </button>
          <button
            onClick={() => onOpen("images")}
            disabled={images === 0}
            className="flex flex-1 items-center justify-center gap-1.5 rounded-full px-3 py-2 text-sm font-semibold text-slate-600 transition hover:bg-white hover:shadow disabled:cursor-not-allowed disabled:text-slate-300"
          >
            <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <rect x="3" y="5" width="18" height="14" rx="2" />
              <path strokeLinecap="round" strokeLinejoin="round" d="M3 15l5-4 4 3 3-2 6 4" />
            </svg>
            Images
            {images > 0 && (
              <span className="rounded-full bg-slate-200 px-1.5 py-0.5 text-[11px] font-bold text-slate-600">
                {images}
              </span>
            )}
          </button>
          <button
            onClick={() => onOpen("video")}
            disabled={videos === 0}
            className="flex flex-1 items-center justify-center gap-1.5 rounded-full px-3 py-2 text-sm font-semibold text-slate-600 transition hover:bg-white hover:shadow disabled:cursor-not-allowed disabled:text-slate-300"
          >
            <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <rect x="3" y="6" width="13" height="12" rx="2" />
              <path strokeLinecap="round" strokeLinejoin="round" d="M16 10l5-3v10l-5-3" />
            </svg>
            Video
          </button>
        </div>
      </div>
    </article>
  );
}
